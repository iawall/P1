For Project 2:

I copied my P1 to a seperate folder and repository, keeping my conda environment the same (with the same path for it on VScode)

.py files contain more information on how the program runs

run.py is just used for the list of URLs, use this when running the program

scrap.py does most of the work dealing with the location for the data (getting data to its respective area) while
scrapper.py contains the class to scrape data

processed folder in Data contains the scraped data